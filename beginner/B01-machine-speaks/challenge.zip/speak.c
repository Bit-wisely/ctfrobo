#include <stdio.h>

int main() {
    const char *binary_lines[] = {
        "01100010",
        "01101001",
        "01101110",
        "01100001",
        "01110010",
        "01111001",
        "00100000",
        "01110011",
        "01110000",
        "01100101",
        "01100001",
        "01101011",
        "01110011"
    };
    int count = sizeof(binary_lines) / sizeof(binary_lines[0]);
    for (int i = 0; i < count; i++) {
        printf("%s\n", binary_lines[i]);
    }
    return 0;
}
